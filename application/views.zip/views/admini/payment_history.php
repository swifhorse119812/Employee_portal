<?php
	$this->load->view('common/header.php');
?>
<style type="text/css">
  .customer-details{
    cursor: pointer;
    color: #409abd;
  }
</style>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Transaction History</h3>
              </div>
            </div>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Transaction History</h2>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <div class="table-responsive">
                      <table id="example" class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings" style="background-color:#24652e">
                            <th>Transaction Id</th>
                            <th>Transaction Date</th>
                            <th>Merchant</th>
                            <th>Type</th>
                            <th>Customer Name</th>
                            <th>Gross</th>
                            <th>Fee</th>
                            <th>Net</th>
                            <th>Status</th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php
                                $transactions = get_rows("transaction",array(),"date DESC");
                                foreach ($transactions as $key => $transaction) {
                                  $member = get_row("member",array("id"=>$transaction['user_id']));
                                    echo "<tr>";
                                    echo '<td>'.$transaction['id'].'</td>';
                                    echo '<td>'.$transaction['date'].'</td>';
                                    echo '<td>'.$member['first_name']." ".$member["last_name"].'</td>';
                                    if($transaction['payment_type'] == "checkout"){
                                        echo '<td>Payment from</td>';
                                        echo '<td><a class="customer-details" data-publish_key="'.$transaction['publish_key'].'">'.$transaction['first_name']." ".$transaction['last_name'].'</a></td>';
                                        echo '<td>$'.$transaction['price'].'USD</td>';
                                        echo '<td>$'.$transaction['fee'].'USD</td>';
                                        echo '<td>$'.($transaction['price']-$transaction['fee']).'USD</td>';
                                    } else if($transaction['payment_type'] == "service_fee") {
                                        echo '<td>Service Fee</td>';
                                        echo '<td> - </td>';
                                        echo '<td> - </td>';
                                        echo '<td>$'.$transaction['fee'].'USD</td>';
                                        echo '<td style="color:blue;">-$'.$transaction['fee'].'USD</td>';
                                    } else if($transaction['payment_type'] == "withdraw_money"){
                                        echo '<td>Withdraw</td>';
                                        echo '<td>-</td>';
                                        $fee = $transaction['price']*$transaction['fee']/100;;
                                        echo '<td>$'.$transaction['price'].'USD</td>';
                                        echo '<td>$'.$fee.'USD ('.$transaction['fee'].'%)</td>';
                                        echo '<td style="color:red;">-$'.($transaction['price']-$fee).'USD</td>';
                                    }
                                    echo '<td>'.$transaction['status'].'</td>';
                                    echo "</tr>";

                                }
                             ?>
                        </tbody>
                      </table>
                    </div>
              
            
                  </div>
                </div>
              </div>
            </div>
          </div>
       
        </div> 
       <!-- /page content -->

<div class="modal fade in" id="transaction_modal" aria-hidden="false" style="display: none;">
  <div class="modal-dialog" style="width: 700px;">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" aria-hidden="true" data-dismiss="modal">×</button>
            <h3 class="modal-title">Transaction Details</h3>
        </div>
        <div class="modal-body" style="padding: 10px 0px;">
         <!--  <img id="featureimage" src=""/> -->
              
        </div>
        <div class="modal-footer">
            <button class="btn" data-dismiss="modal"> Close </button>
        </div>
    </div>
  </div>
</div>


<?php
	$this->load->view('common/footer.php');
?>
<script >

   $.extend( true, $.fn.dataTable.defaults, {
        "searching": true,
        "ordering": false
    } );


    $(document).ready(function() {
    var table = $('#example').DataTable( {
         "dom": "<'row'<'col-sm-8'B><'col-sm-1'l><'col-sm-1'f>>" +
                    "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        buttons: [
            'csv', 'print'
        ],
         

    } );

    // For demo to fit into DataTables site builder...
    $('#example')
        .removeClass( 'display' )
         .addClass('table table-striped table-bordered');

    $(".col-sm-1").removeClass("col-sm-1");

    $(".col-sm-1").removeClass("col-sm-1");
        
} );
   

  $(document).ready(function(){

    $("body").on("click",".customer-details",function(){
        publish_key = $(this).data("publish_key");
        $.ajax({
            url: "<?php echo base_url("account/get_transaction"); ?>",
            data:{publish_key:publish_key},
            dataType:"html",
            type:"post",
            success: function(res){
                $("#transaction_modal .modal-body").html(res);
                $("#transaction_modal").modal();
            }
        })

    })

    $('#image-upload').change(function(){
      $('#flg_change').val('1');
    });
    $("body").on("click",".feature-edit",function(){
        id = $(this).data("id");
        $.ajax({
          url: BASE_URL + "admini/feature/getfeatureData",
          data:{"id":id},
          dataType:"json",
          type:"post",
          success: function(res){
            
            $("#view_modal").modal();
            $("#id").val(id);
            $("#name").val(res.data.name);
            $("#category_id option[value='"+res.data.category_id+"']").prop("selected","selected");
             
            if (res.data.allowstatus==1){

              $("#featurestatus").attr("checked","checked");
              $(".icheckbox_flat-green").addClass("checked")
            }
          }
        })
    });

     $("body").on("click",".feature-delete",function(){
        id = $(this).data("id");
        obj = $(this).closest("tr");
        $.ajax({
          url: BASE_URL + "admini/feature/deletefeatureData",
          data:{"id":id},
          dataType:"json",
          type:"post",
          success: function(res){
            obj.remove();
          }
        })
    });
    $("body").on("click","#editcancel",function(){
       $("#view_modal").modal("toggle");
    });
$.uploadPreview({
    input_field: "#image-upload",   // Default: .image-upload
    preview_box: "#image-preview",  // Default: .image-preview
    label_field: "#image-label",    // Default: .image-label
    label_default: "Choose File",   // Default: Choose File
    label_selected: "Change File",  // Default: Change File
    no_label: false                 // Default: false
  });
  });

</script>

