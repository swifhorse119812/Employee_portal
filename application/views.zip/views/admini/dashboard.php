<?php
  $this->load->view("common/header.php");
?>
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Dashboard</h3>
              </div>
            </div>
            <?php
                $payment = get_row("paymentgetway",array("id"=>1));
                $fee = $payment['checkout_fee'];
                $transactions = get_rows("transaction",array("payment_type"=>"checkout"),"date DESC");
                $day_data = array();
                $day = "";
                $row = array();
                $no = 0;
                $row['date'] = "";
                $row['sold_amout'] = 0;
                $row['total_price'] = 0;
                $total_price = 0;
                $total_sold = 0;

                $total_price_year = 0;
                $total_sold_year= 0;
                $total_price_month = 0;
                $total_sold_month = 0;
                $total_price_week = 0;
                $total_sold_week = 0;
                $total_price_day = 0;
                $total_sold_day = 0;

                $total_checkout_fee = 0;
                $total_checkout_fee_year = 0;
                $total_checkout_fee_month = 0;
                $total_checkout_fee_week = 0;
                $total_checkout_fee_day = 0;

                $first_day_of_the_week = 'Sunday';
                $start_of_the_week     = strtotime("Last $first_day_of_the_week");
                if ( strtolower(date('l')) === strtolower($first_day_of_the_week) )
                {
                    $start_of_the_week = strtotime('today');
                }
                $end_of_the_week = $start_of_the_week + (60 * 60 * 24 * 7) - 1;
                // $date_format =  'l jS \of F Y h:i:s A';
                $first_date =  date("Y-m-d", $start_of_the_week);
                $end_date = date("Y-m-d", $end_of_the_week);
                

                foreach ($transactions as $key => $transaction) {
                  $total_price += $transaction['price']-$fee;
                  $total_sold ++;
                  $total_checkout_fee += $transaction['fee'];
                  if(strpos($transaction['date'], date("Y-"))!== false){
                    $total_price_year += $transaction['price']-$fee;
                    $total_sold_year ++;
                    $total_checkout_fee_year += $transaction['fee'];
                  }

                  if(strpos($transaction['date'], date("Y-m-"))!== false){
                    $total_price_month += $transaction['price']-$fee;
                    $total_sold_month ++;
                    $total_checkout_fee_month += $transaction['fee'];

                  }

                  if(strpos($transaction['date'], date("Y-m-d"))!== false){
                    $total_price_day += $transaction['price']-$fee;
                    $total_sold_day ++;
                    $total_checkout_fee_day += $transaction['fee'];

                  }

                  if($first_date<=$transaction['date']&&$end_date>=$transaction['date']){
                    $total_price_week += $transaction['price']-$fee;
                    $total_checkout_fee_week += $transaction['fee'];
                    $total_sold_week ++;
                  }


                  $t_day = substr($transaction['date'],0,10);
                  if($day!=$t_day){
                    $no++;
                    if($no!=1){
                      array_push($day_data, $row);
                    }
                    $day = $t_day;
                    $row['date'] = $t_day;
                    $row['sold_amout'] = 0;
                    $row['total_price'] = 0;
                  }
                  $row['sold_amout'] ++;
                  $row['total_price'] += $transaction['price']-$fee;
                }
                if($row["sold_amout"]!=0){
                  array_push($day_data, $row);
                }

                $transactions = get_rows("transaction",array("payment_type"=>"withdraw_money"));
                $total_transaction_fee = 0;
                $total_transaction_fee_year = 0;
                $total_transaction_fee_month = 0;
                $total_transaction_fee_week = 0;
                $total_transaction_fee_day = 0;

                foreach ($transactions as $key => $transaction) {
                  $fee = $transaction['price'] * $transaction['fee']/100;
                  $total_transaction_fee += $fee;
                  if(strpos($transaction['date'], date("Y-"))!== false){
                    $total_transaction_fee_year += $fee;
                   
                  }

                  if(strpos($transaction['date'], date("Y-m-"))!== false){
                    $total_transaction_fee_month += $fee;
                     
                  }

                  if(strpos($transaction['date'], date("Y-m-d"))!== false){
                    $total_transaction_fee_day += $fee;
                  }

                  if($first_date<=$transaction['date']&&$end_date>=$transaction['date']){
                    $total_transaction_fee_week += $fee;
                  }
                }

                $transactions = get_rows("transaction",array("payment_type"=>"service_fee"));
                $total_service_fee = 0;
                $total_service_fee_year = 0;
                $total_service_fee_month = 0;

                foreach ($transactions as $key => $transaction) {
                  $fee = $transaction['fee'];
                  $total_service_fee += $fee;
                  if(strpos($transaction['date'], date("Y-"))!== false){
                    $total_service_fee_year += $fee;
                  }

                  if(strpos($transaction['date'], date("Y-m-"))!== false){
                    $total_service_fee_month += $fee;
                     
                  }
                }


            ?>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-4" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Checkout Fee
                    <span class="pull-right text-success">$<?php echo $total_checkout_fee; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">Today : <span class="text-success">$<?php echo $total_checkout_fee_day; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Week : <span class="text-success">$<?php echo $total_checkout_fee_week; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-success">$<?php echo $total_checkout_fee_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-success">$<?php echo $total_checkout_fee_year; ?></span></span>
                  </div>
                </div>
              </div>
              <div class="col-md-4" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Transaction Fee
                    <span class="pull-right text-info">$<?php echo $total_transaction_fee; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">Today : <span class="text-info">$<?php echo $total_transaction_fee_day; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Week : <span class="text-info">$<?php echo $total_transaction_fee_week; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-info">$<?php echo $total_transaction_fee_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-info">$<?php echo $total_transaction_fee_year; ?></span></span>
                  </div>
                </div>
              </div>
              <div class="col-md-4" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Service Fee
                    <span class="pull-right text-warning">$<?php echo $total_service_fee; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-warning">$<?php echo $total_service_fee_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-warning">$<?php echo $total_service_fee_year; ?></span></span>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Price
                    <span class="pull-right text-success">$<?php echo $total_price; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">Today : <span class="text-success">$<?php echo $total_price_day; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Week : <span class="text-success">$<?php echo $total_price_week; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-success">$<?php echo $total_price_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-success">$<?php echo $total_price_year; ?></span></span>
                  </div>
                </div>
              </div>

              <div class="col-md-6" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Sold Amount
                    <span class="pull-right text-warning"><?php echo $total_sold; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">Today : <span class="text-warning"><?php echo $total_sold_day; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Week : <span class="text-warning"><?php echo $total_sold_week; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-warning"><?php echo $total_sold_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-warning"><?php echo $total_sold_year; ?></span></span>
                  </div>
                </div>
              </div>

             <!--  <div class="col-md-4" style="padding: 10px;">
                <div style="border: 1px solid #ccc;padding: 30px 20px;height: 150px;">
                  <div style="font-size: 25px;border-bottom: 1px solid #e0dede;padding-bottom: 10px;">
                    Total Merchants
                    <span class="pull-right text-warning"><?php echo $total_sold; ?></span>
                  </div>
                  <div style="width: 100%;margin-top: 40px;font-size: 14px;">
                    <span class="pull-right" style="margin-left: 20px;">Today : <span class="text-warning"><?php echo $total_sold_day; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Week : <span class="text-warning"><?php echo $total_sold_week; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Month : <span class="text-warning"><?php echo $total_sold_month; ?></span></span>
                    <span class="pull-right" style="margin-left: 20px;">This Year : <span class="text-warning"><?php echo $total_sold_year; ?></span></span>
                  </div>
                </div>
              </div> -->

            </div>
            <div class="row">
              <div class="col-md-12">
              <div class="table-responsive">
                <p style="margin-bottom: 10px; font-size: 20px; margin-top: 50px;">
                  Product Transactions by each date
                </p>
                      <table id="example" class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings" style="background-color:#24652e">
                            <th>Date</th>
                            <th>Sold Products Amount</th>
                            <th>Total Sold Price</th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php
                            
                              foreach ($day_data as $key => $row) {
                                echo "<tr>";
                                echo "<td>".$row['date']."</td>";
                                echo "<td>".$row['sold_amout']."</td>";
                                echo "<td>$".$row['total_price']."</td>";
                                echo "</tr>";
                              }
                           ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
            </div>
        </div>
      </div>
 <div class="modal fade in" id="order_detail" aria-hidden="false" style="display: none;">
  
 </div>
 
<?php
	$this->load->view("common/footer.php");
?>

<script type="text/javascript">

   $.extend( true, $.fn.dataTable.defaults, {
        "searching": true,
        "ordering": false
    } );

  $('document').ready(function(){

 if( typeof ($.fn.DataTable) === 'undefined'){ return; }
    var table = $('#example').DataTable( {
         "dom": "<'row'<'col-sm-8'B><'col-sm-1'l><'col-sm-1'f>>" +
                    "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        buttons: [
            'csv', 'print'
        ],
         

    } );

    // For demo to fit into DataTables site builder...
    $('#example')
        .removeClass( 'display' )
         .addClass('table table-striped table-bordered');

    $(".col-sm-1").removeClass("col-sm-1");
    $(".col-sm-1").removeClass("col-sm-1");
})

</script>

