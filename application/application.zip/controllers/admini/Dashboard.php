<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Admin_Controller {

	function __construct()
    {
    	ini_set("max_execution_time","-1");
	    ini_set("max_input_time","-1");
	    ini_set("memory_limit","15G");
	    ini_set("post_max_size","15G");
	    ini_set("upload_max_filesize","15G");
        parent::__construct();
    
    }

	public function index()
	{
		$this->load->view("admini/dashboard");

	}
	public function get_chart_data(){
		$rows = get_rows("transaction",array("payment_type"=>"checkout","status!="=>"Refund"),"date ASC");
		$data = array();
		foreach ($rows as $key => $row) {
			$data_array = array();
			$date = strtotime($row['date']);
			array_push($data_array, $date*1000);
			array_push($data_array, $row['price']*1);
			array_push($data_array, $row['price']*1);
			array_push($data_array, $row['price']*1);
			array_push($data, $data_array);
		}

		echo json_encode($data);
	}
	public function get_pipe_data(){
		$members = get_rows("member");
		$data = array();
		foreach ($members as $key => $member) {
			$data_array = array();
			$data_array['name'] = $member['first_name']." ".$member['last_name'];
			$rows = get_rows("transaction",array("user_id"=>$member['id'], "payment_type"=>"checkout","status!="=>"Refund"),"date ASC");
			$data_array['y'] = 0;
			foreach ($rows as $key => $row) {
				$data_array['y'] += $row['price'];
			}
			array_push($data, $data_array);

		}
		echo json_encode($data);
	}

	public function download_report(){
		$data = $this->input->post();
		$date1 = strtotime($data['from_date']);
		$from_date = date("Y-m-d",$date1);

		$date1 = strtotime($data['to_date']);
		$to_date = date("Y-m-d 23:59:59",$date1);
		
		if($data['date_type'] == 1){
			$from_date = date("Y-01-01");
			$to_date = date("Y-m-d 23:59:59");
		}

		if($data['date_type'] == 2){
			$from_date = date("Y-m-01");
			$to_date = date("Y-m-d 23:59:59");
		}

		if($data['date_type'] == 4){
			$from_date = date("Y-m-d");
			$to_date = date("Y-m-d 23:59:59");
		}
		
		if($data['date_type'] == 3){
			$first_day_of_the_week = 'Sunday';
            $start_of_the_week     = strtotime("Last $first_day_of_the_week");
            if ( strtolower(date('l')) === strtolower($first_day_of_the_week) )
            {
                $start_of_the_week = strtotime('today');
            }
            $end_of_the_week = $start_of_the_week + (60 * 60 * 24 * 7) - 1;
            // $date_format =  'l jS \of F Y h:i:s A';
            $from_date =  date("Y-m-d", $start_of_the_week);
            $to_date = date("Y-m-d 23:59:59", $end_of_the_week);
		}
 
	    ini_set("max_execution_time","-1");
	    ini_set("max_input_time","-1");
	    ini_set("memory_limit","15G");
	    ini_set("post_max_size","15G");
	    ini_set("upload_max_filesize","15G");
	    set_time_limit(100000);
	    $report_type = $this->input->post("report_type");
	    $download_type = $this->input->post("download_type");
	    
	    if($download_type == 1){
			$html = $this->load->view('admini/'.$report_type,array("from_date"=>$from_date,"to_date"=>$to_date),TRUE);
		    $this->load->library('pdf');
	        $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
			$pdf->SetTitle('My Title');
			$pdf->SetHeaderMargin(30);
			// $pdf->SetTopMargin(0);
			// $pdf->setFooterMargin(0);
			$pdf->SetAutoPageBreak(true);
			$pdf->SetAuthor('Author');
			// $pdf->SetDisplayMode('real', 'default');
			$pdf->AddPage();
			 
			$pdf->writeHTML($html, true, false, false, false, '');
			$pdf->Output($report_type.'.pdf', 'D');
		} else {
			$this->load->view('admini/'.$report_type."_excel",array("from_date"=>$from_date,"to_date"=>$to_date),TRUE);

		}

	}

	public function download_pdf($filename){
		$filename1 = "reports/".$filename;
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Content-type: application/pdf');
		readfile(base_url().$filename1);
		die();
	}



}
