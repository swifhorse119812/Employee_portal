/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Arrow Symbols
 *
 * (c) 2017-2019 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/ArrowSymbols.js';
